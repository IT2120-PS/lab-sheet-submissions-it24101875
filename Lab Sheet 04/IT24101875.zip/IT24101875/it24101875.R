setwd("C:\\Users\\it24101875\\Desktop\\IT24101875")
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
head(branch_data) # Shows the first few rows of the data frame
str(branch_data)  # Shows the structure, including variable names and types
boxplot(branch_data$Sales_X1, main = "Boxplot for Sales")
summary(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

get.outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  outliers <- sort(z[z < lb | z > ub])
  print(paste("Outliers:", paste(outliers, collapse = ",")))
}

get.outliers(branch_data$Years_X3)